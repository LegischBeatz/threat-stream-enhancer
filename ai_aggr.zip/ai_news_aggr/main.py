# main.py

import feedparser
from llm_utils import generate_response

# RSS feeds for different categories
RSS_FEEDS = {
    'cybersecurity': [
        "https://news.ycombinator.com/rss",
        "https://www.infosecurity-magazine.com/rss/news/",
    ],
    'general': [
        "https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml",
        "https://feeds.bbci.co.uk/news/rss.xml",
        "https://www.theguardian.com/world/rss"
    ]
}

def fetch_articles():
    """Fetch two articles per RSS feed."""
    articles = {}
    for category, urls in RSS_FEEDS.items():
        articles[category] = []
        for url in urls:
            feed = feedparser.parse(url)
            for entry in feed.entries[:1]:  # Limit to 2 articles per feed
                article = {
                    'title': entry.title,
                    'link': entry.link,
                    'published': entry.published if 'published' in entry else 'N/A',
                    'summary': entry.summary if 'summary' in entry else 'No summary available'
                }
                articles[category].append(article)
    return articles

def generate_satirical_summary(articles):
    """Generate a satirical summary based on the fetched articles."""
    # Create a prompt for the LLM to generate a satirical summary
    prompt = "Summarize today's news with a satirical and humorous tone, like a funny news reporter. The articles are: "
    for category, articles_list in articles.items():
        for article in articles_list:
            prompt += f"Title: {article['title']}. Summary: {article['summary']}. "

    # Generate the satirical summary using the LLM
    satirical_summary = generate_response(prompt)
    return satirical_summary

def main():
    # Fetch articles from RSS feeds
    articles = fetch_articles()

    # Print fetched articles
    print("\n=== Fetched Articles ===\n")
    for category, articles_list in articles.items():
        print(f"{category.capitalize()} News:")
        for article in articles_list:
            print(f"Title: {article['title']}")
            print(f"Link: {article['link']}")
            print(f"Published: {article['published']}")
            print(f"Summary: {article['summary']}")
            print("")

    # Generate satirical summary
    print("\n=== Satirical Summary ===\n")
    satirical_summary = generate_satirical_summary(articles)
    print(satirical_summary)

if __name__ == '__main__':
    main()
