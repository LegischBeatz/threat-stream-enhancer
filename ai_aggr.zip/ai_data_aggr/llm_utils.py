# llm_utils.py

import requests
import json

LLM_API_URL = "http://localhost:11434/api/generate"
HEADERS = {"Content-Type": "application/json"}

def generate_response(prompt, model="phi3"):
    """Send a prompt to the LLM API and get the response."""
    payload = {
        "model": model,
        "prompt": prompt
    }
    response = requests.post(LLM_API_URL, json=payload, headers=HEADERS, stream=True)
    generated_text = ""

    if response.status_code == 200:
        for line in response.iter_lines():
            if line:
                json_obj = json.loads(line)
                generated_text += json_obj.get('response', '')
        return generated_text.strip()
    else:
        error_message = f"Error: Received status code {response.status_code} from LLM API."
        print(error_message)
        return error_message
