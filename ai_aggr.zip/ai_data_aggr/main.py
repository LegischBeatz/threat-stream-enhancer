# main.py

from llm_utils import generate_response

def main():
    # First prompt: Generate three random words
    first_prompt = "Create 3 short hypothesis why its important to stay in a crew like guardians of the galaxy in the verse of star citicen."
    first_response = generate_response(first_prompt)

    if "Error" in first_response:
        print(first_response)
        return

    print("Random Words:")
    print(first_response)
    print()

    # Second prompt: Use the words to create a short story
    second_prompt = f"Using the following hypothesis: {first_response}, create a motivational message for the players so they feel urged to play in the verse."
    second_response = generate_response(second_prompt)

    if "Error" in second_response:
        print(second_response)
        return

    print("Generated Story:")
    print(second_response)

if __name__ == '__main__':
    main()
